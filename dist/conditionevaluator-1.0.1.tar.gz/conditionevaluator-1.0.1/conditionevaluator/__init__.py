# -*- coding: utf-8 -*-
# @File    : __init__.py.py
from . import conditionevaluator


__version__ = "1.0.0"
